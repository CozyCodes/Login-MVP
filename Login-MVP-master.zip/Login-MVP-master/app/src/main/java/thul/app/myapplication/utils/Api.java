package thul.app.myapplication.utils;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;
import thul.app.myapplication.responses.LoginResp;

public interface Api {

    @POST("user_login.php")
    Observable<LoginResp> getUserlogin(@Body RequestBody body);
}
