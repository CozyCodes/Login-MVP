package thul.app.myapplication.responses;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class LoginResp {

    public String getRes_msg() {
        return res_msg;
    }

    public void setRes_msg(String res_msg) {
        this.res_msg = res_msg;
    }

    public String getRes_code() {
        return res_code;
    }

    public void setRes_code(String res_code) {
        this.res_code = res_code;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_login() {
        return user_login;
    }

    public void setUser_login(String user_login) {
        this.user_login = user_login;
    }

    public String getUser_nicename() {
        return user_nicename;
    }

    public void setUser_nicename(String user_nicename) {
        this.user_nicename = user_nicename;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getDisplay_name() {
        return display_name;
    }

    public void setDisplay_name(String display_name) {
        this.display_name = display_name;
    }

    public String getPhone_one() {
        return phone_one;
    }

    public void setPhone_one(String phone_one) {
        this.phone_one = phone_one;
    }

    @SerializedName("user_id")
    private String user_id;

    @SerializedName("user_login")
    private String user_login;

    @SerializedName("user_nicename")
    private String user_nicename;

    @SerializedName("user_email")
    private String user_email;

    @SerializedName("display_name")
    private String display_name;

    @SerializedName("phone_one")
    private String phone_one;

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    @SerializedName("language")
    private String language;

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    @SerializedName("user_type")
    private String user_type;

    public String getHome_address() {
        return home_address;
    }

    public void setHome_address(String home_address) {
        this.home_address = home_address;
    }

    @SerializedName("home_address")
    private String home_address;

    @SerializedName("res_msg")
    private String res_msg;

    @SerializedName("res_code")
    private String res_code;

    @SerializedName("data")
    @Expose
    private ArrayList<LoginResp> login = new ArrayList<>();

    public ArrayList<LoginResp> getLogin() {
        return login;
    }
}