package thul.app.myapplication.model;

import android.util.Log;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import thul.app.myapplication.presenter.LoginModel;
import thul.app.myapplication.responses.LoginResp;
import thul.app.myapplication.utils.Api;

public class LoginUserModel implements LoginModel.Model {


    @Override
    public void getLoginDetails(final OnFinishedListener onFinishedListener,String uname,String pass) {

        Retrofit retrofit = new Retrofit.Builder()

                .baseUrl("http://thulasiram.in/tailorapp/apis/")

                .addConverterFactory(GsonConverterFactory.create())

                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())

                .build();


        Api apiService = retrofit.create(Api.class);

        JSONObject paramObject = null;

        try {

            paramObject = new JSONObject();

            paramObject.put("username", uname);

            paramObject.put("password", pass);

            Log.v("paramObject",paramObject.toString());

        } catch (JSONException e) {

            e.printStackTrace();

        }

        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"),paramObject.toString() );

        final Observable<LoginResp> observable = apiService.getUserlogin(requestBody).subscribeOn

                (Schedulers.newThread())

                .observeOn(AndroidSchedulers.mainThread());



        observable.subscribe(new Observer<LoginResp>() {



            @Override

            public void onSubscribe(Disposable d) {



            }



            @Override

            public void onNext(LoginResp value) {

                String user_id ="";

                List<LoginResp> orderVal = value.getLogin();

                Log.v("get_response",value.getRes_msg());

                String res_msg = value.getRes_msg();
                onFinishedListener.onFinished(value);






//                            Toast.makeText(CommonActivity.this, user_id, Toast.LENGTH_SHORT).show();


            }



            @Override

            public void onError(Throwable e) {

                Log.d("error",e.toString());
                onFinishedListener.onFailure(e);

            }



            @Override

            public void onComplete() {

                Log.v("inhere","--");

//                observable.unsubscribeOn(Schedulers.newThread());

            }





        });



    }
}