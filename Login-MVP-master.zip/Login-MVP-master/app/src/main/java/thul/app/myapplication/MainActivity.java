package thul.app.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import thul.app.myapplication.presenter.LoginModel;
import thul.app.myapplication.presenter.LoginPresenterImpl;
import thul.app.myapplication.responses.LoginResp;

public class MainActivity extends AppCompatActivity implements LoginModel.View, View.OnClickListener {
    private EditText editUser;
    private EditText editPass;
    private Button btnLogin;
    private Button btnClear;
    private ProgressBar progressBar;
    LoginModel.Presenter loginPresenter;
    LoginModel.View loginViw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //find view
        editUser = (EditText) this.findViewById(R.id.et_login_username);
        editPass = (EditText) this.findViewById(R.id.et_login_password);
        btnLogin = (Button) this.findViewById(R.id.btn_login_login);
        btnClear = (Button) this.findViewById(R.id.btn_login_clear);
        progressBar = (ProgressBar) this.findViewById(R.id.progress_login);

        //set listener
        btnLogin.setOnClickListener(this);
        btnClear.setOnClickListener(this);

        //init
        loginPresenter = new LoginPresenterImpl(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login_clear:
//                loginPresenter.clear();
                break;
            case R.id.btn_login_login:
//                loginPresenter.setProgressBarVisiblity(View.VISIBLE);
//                btnLogin.setEnabled(false);
//                btnClear.setEnabled(false);
//                loginPresenter.doLogin(editUser.getText().toString(), editPass.getText().toString());
                loginPresenter.requestLoginData(editUser.getText().toString(), editPass.getText().toString());
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        loginPresenter.onDestroy();
    }


    @Override
    public void showProgress() {
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgress() {
        progressBar.setVisibility(View.INVISIBLE);
    }

    @Override
    public void setDataToViews(LoginResp resp) {
        Log.v("get_response",resp.getRes_msg());
    }

    @Override
    public void onResponseFailure(Throwable throwable) {

    }
}
