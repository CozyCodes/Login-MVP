package thul.app.myapplication.presenter;

import java.util.List;

import thul.app.myapplication.responses.LoginResp;

public interface LoginModel {

    interface Model {

        interface OnFinishedListener {
            void onFinished(LoginResp resp);

            void onFailure(Throwable t);
        }

        void getLoginDetails(OnFinishedListener onFinishedListener, String uname, String pass);
    }

    interface Presenter {
        void onDestroy();

        void requestLoginData( String uname, String pass );
    }
    interface View {

        void showProgress();

        void hideProgress();

        void setDataToViews(LoginResp resp);

        void onResponseFailure(Throwable throwable);
    }
}
