package thul.app.myapplication.presenter;


import thul.app.myapplication.model.LoginUserModel;
import thul.app.myapplication.responses.LoginResp;


public class LoginPresenterImpl implements LoginModel.Presenter,LoginModel.Model.OnFinishedListener {
    LoginModel.View iLoginView;
    LoginModel.Model getLoginDetails;


    public LoginPresenterImpl(LoginModel.View iLoginView) {
        this.iLoginView = iLoginView;
        this.getLoginDetails = new LoginUserModel();
        iLoginView.hideProgress();
    }




    @Override
    public void onDestroy() {
        iLoginView = null;
    }

    @Override
    public void requestLoginData(String uname, String pass) {
        iLoginView.showProgress();
        getLoginDetails.getLoginDetails(this,uname,pass);
    }

    @Override
    public void onFinished(LoginResp resp) {
        iLoginView.hideProgress();
        iLoginView.setDataToViews(resp);
    }

    @Override
    public void onFailure(Throwable t) {
        iLoginView.hideProgress();
        iLoginView.onResponseFailure(t);
    }
}
